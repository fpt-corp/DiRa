^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package astra_launch
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.2 (2018-03-22)
-----------
* modifty multi launch
* Contributors: tim_liu

0.2.1 (2018-02-12)
------------------
* sync with astra_camera
* Contributors: Tim

0.1.0 (2016-05-27)
------------------
* initial commit
* Contributors: Len Zhong
